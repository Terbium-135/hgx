__version__ = "$Rev: 0 $"
module_version = "0.000"
module_name = "Unknown damage type handler"
'''
'''

import hgx
import Hgx.Core
import NLog
import re
import clr
import locale
import System

from System import DateTime, TimeSpan

locale.setlocale(locale.LC_ALL, '')

# get a logger for the script
logger = NLog.LogManager.GetLogger(__file__)


def on_damaged(sender, e):

	# BEWARE: enabling any output here may slow the parsing process by a HUGE amount
	# logger.Info ("ON_DAMAGED: Attacker: {0}, Defender: {1}, Unknown damage types: {2}".format(e.Attacker, e.Defender, e.HasUnknownDamageType))
	pass


def on_unknown_damage_detected(sender, e):

	# BEWARE: enabling any output here may slow the parsing process by a HUGE amount
	logger.Info ("ON_UNKNOWN_DAMAGE_DETECTED: Attacker: {0}, defender: {1}, line: {2}".format(e.Attacker, e.Defender, e.Line))
	pass


if __name__ == "__main__":

#	hgx.GameEvents.Damaged += on_damaged
	hgx.GameEvents.UnknownDamageTypeDetected += on_unknown_damage_detected
