from Hgx.Core import DamageType
from Hgx.Core import Weapon
from Hgx.Core.Weapons.Dice import WeaponDamageDice

additionalArrowDamage = {
	DamageType.Fire: DamageType.Negative,
	DamageType.Cold: DamageType.Positive,
	DamageType.Acid: DamageType.Magical,
	DamageType.Electrical: DamageType.Divine,
	DamageType.Sonic: DamageType.Divine,
}

class UserControlledWeapon(Weapon):
	def __new__(cls, damage_type):
		self = Weapon.__new__(cls)
		self.damage_type = damage_type
		
		return self

def get_dice_from_level(nLevel):
	if nLevel >= 47:
		return 15
	elif nLevel >= 38:
		return 14
	elif nLevel >= 30:
		return 13
	elif nLevel >= 23:
		return 12
	elif nLevel >= 17:
		return 11
	elif nLevel >= 12:
		return 10
	elif nLevel >= 8:
		return 9
	elif nLevel >= 5:
		return 8
	elif nLevel >= 3:
		return 7
	elif nLevel >= 1:
		return 6
	else:
		return 0


def LegendaryArcherBow(nLevel, bEgo):
	dice = get_dice_from_level(nLevel)
	die = 10 if bEgo else 8

	for dt in (DamageType.Acid, DamageType.Cold, DamageType.Electrical, DamageType.Fire, DamageType.Sonic):
		w = UserControlledWeapon(dt)
		w[dt] = WeaponDamageDice(dice, die)
		w[DamageType.Magical] = WeaponDamageDice(2, 12)
		w[DamageType.Negative] = WeaponDamageDice(2, 12)
		yield w

	for dt in (DamageType.Divine, DamageType.Magical, DamageType.Negative, DamageType.Positive):
		w = UserControlledWeapon(dt)
		w[dt] = WeaponDamageDice(dice - 2, die)
		yield w


def DivineSlingerBullet(nCharacterLevel, nClericLevels):
	nDiv  = nCharacterLevel / 20
	nEle  = nCharacterLevel /  5

	if nClericLevels >= 40:
		damageTypes = (DamageType.Acid, DamageType.Cold, DamageType.Electrical, DamageType.Fire, DamageType.Sonic, DamageType.Divine, DamageType.Magical)
	elif nClericLevels >= 30:
		damageTypes = (DamageType.Acid, DamageType.Cold, DamageType.Electrical, DamageType.Fire, DamageType.Sonic, DamageType.Divine)
	elif nClericLevels >= 25:
		damageTypes = (DamageType.Acid, DamageType.Cold, DamageType.Electrical, DamageType.Fire, DamageType.Sonic)
	elif nClericLevels >= 20:
		damageTypes = (DamageType.Acid, DamageType.Cold, DamageType.Electrical, DamageType.Fire)
	else:
		damageTypes = (DamageType.Cold, DamageType.Fire,)

	for dt in damageTypes:
		w = UserControlledWeapon(dt)
		if dt == DamageType.Divine:
			w[dt] = WeaponDamageDice(nEle + nDiv, 8)
		else:
			w[dt] = WeaponDamageDice(nEle, 8)
			w[DamageType.Divine] = WeaponDamageDice(nDiv, 8)
		yield w


def StaffMaster(nCharacterLevel, nWeaponMasterLevels):
	nEle  = 3 + nWeaponMasterLevels/5
	if nCharacterLevel > 40 and nWeaponMasterLevels >= 20:
		nEle += (nCharacterLevel-40) / 5
	die = 10

	if nWeaponMasterLevels >= 25:
		damageTypes = (DamageType.Acid, DamageType.Cold, DamageType.Electrical, DamageType.Fire, DamageType.Sonic, DamageType.Negative, DamageType.Magical, DamageType.Positive)
	elif nWeaponMasterLevels >= 20:
		damageTypes = (DamageType.Acid, DamageType.Cold, DamageType.Electrical, DamageType.Fire, DamageType.Sonic, DamageType.Magic)
	elif nWeaponMasterLevels >= 16:
		damageTypes = (DamageType.Acid, DamageType.Cold, DamageType.Electrical, DamageType.Fire, DamageType.Sonic)
	elif nWeaponMasterLevels >= 12:
		damageTypes = (DamageType.Acid, DamageType.Cold, DamageType.Electrical, DamageType.Fire)
	elif nWeaponMasterLevels >= 8:
		damageTypes = (DamageType.Electrical, DamageType.Cold, DamageType.Fire,)
	elif nWeaponMasterLevels >= 4:
		damageTypes = (DamageType.Cold, DamageType.Fire,)
	else:
		damageTypes = (DamageType.Fire,)

	for dt in damageTypes:
		w = UserControlledWeapon(dt)
		w[dt] = WeaponDamageDice(nEle, die)
		yield w


def LegendaryRangerBow(nLevel, bEgo):
	dice = 6 # 7 if using separate bows
	die = 10 if bEgo else 8

	for dt in (DamageType.Acid, DamageType.Cold, DamageType.Electrical, DamageType.Fire, DamageType.Sonic):
		w = UserControlledWeapon(dt)
		w[dt] = WeaponDamageDice(dice, die)
		w[additionalArrowDamage[dt]] = WeaponDamageDice(2, 12)
		yield w

