__all__ = ["LegendaryArcherBow", "DivineSlingerBullet",
           "Settings", "Statistics", "Characters", "Encounters", "Timers",
#           "GameEvents", "UserEvents", "Messages", "Xml", "Client", "Overlays"]
           "GameEvents", "UserEvents", "Messages", "Xml"]

import clr

for name in ["System.Core",
             "System.Drawing",
			 "System.Reactive.Core",
             "System.Reactive.Interfaces",
             "System.Reactive.Linq",
             "System.Reactive.PlatformServices",
             "System.Windows.Forms",
             "Microsoft.Practices.Unity",
             "Microsoft.Practices.Unity.Configuration",
             "Microsoft.Practices.ServiceLocation",
             "NLog",
             "Hgx.Core",
             "Hgx.Client",
             "Hgx.Services",
             "Hgx.Modules",
             "Hgx.Scripting",
             "Hgx.Reporting"]:
	clr.AddReference(name)
		
import System
import NLog
import Hgx.Core
import Hgx.Services
#import Hgx.Modules
from Microsoft.Practices.Unity import IUnityContainer, ContainerControlledLifetimeManager
from Microsoft.Practices.ServiceLocation import ServiceLocator

from clrtype import *
from weapons import LegendaryArcherBow
from weapons import DivineSlingerBullet
from weapons import StaffMaster
from weapons import LegendaryRangerBow

_logger    = NLog.LogManager.GetLogger(__file__)

Container   = ServiceLocator.Current.GetInstance[IUnityContainer]()
Settings    = ServiceLocator.Current.GetInstance[Hgx.Core.ISettings]()
Statistics  = ServiceLocator.Current.GetInstance[Hgx.Core.IStatistics]()
Characters  = ServiceLocator.Current.GetInstance[Hgx.Core.ICharacterDatabase]()
Encounters  = ServiceLocator.Current.GetInstance[Hgx.Core.IEncounters]()
Timers      = ServiceLocator.Current.GetInstance[Hgx.Core.IStatusRuleDatabase]()
GameEvents  = ServiceLocator.Current.GetInstance[Hgx.Services.Compat.GameEvents]()
UserEvents  = ServiceLocator.Current.GetInstance[Hgx.Services.Compat.UserEvents]()
Messages    = ServiceLocator.Current.GetInstance[Hgx.Core.IMessages]()
Xml         = ServiceLocator.Current.GetInstance[Hgx.Core.IXmlQueryDatabase]()
Client      = ServiceLocator.Current.GetInstance[Hgx.Core.IClient]()
#Overlays    = ServiceLocator.Current.GetInstance[Hgx.Core.IOverlay]()
#Context     = ServiceLocator.Current.GetInstance[Hgx.Core.IContext]()
Overlays    = ServiceLocator.Current.GetInstance[Hgx.Core.IOverlayManager]()
IUserEvents = ServiceLocator.Current.GetInstance[Hgx.Core.IUserEvents]()


